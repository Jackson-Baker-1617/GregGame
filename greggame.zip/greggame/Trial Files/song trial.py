#import pygame
#from pygame import *

#mixer.init()
#mixer.music.load('/Users/jacksonbaker/Desktop/the greg game/EGG.mp3/Users/jacksonbaker/Desktop/the greg game')
#mixer.music.play()

import os

os.system(Users/jacksonbaker/Desktop/greggame/EGG.mp3)
