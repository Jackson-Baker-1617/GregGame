from tkinter import *

def loadpage():
    geometry("500x500")
    title("A game with a title to be decided later")
    
