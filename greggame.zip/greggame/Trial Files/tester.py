from tkinter import *
def all():
    win = Tk()
    win.geometery = ("5000x5000")
all()
