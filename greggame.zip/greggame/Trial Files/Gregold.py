from tkinter import *

class Startup():
    def start(self, master):
        self.master=master
        self.master.geometry("500x500")
        self.title("Greg's Game")

        self.butone = Button(self.master, text="Start", command=self.go)
        self.butone.place(x=200, y=200)

        self.buttwo = Button(self.master, text="Quit", command=self.stop)
        self.buttwo.place(x=200, y=400)

    def go(self):
        login1.init()
    def stop():
        self.master.destroy()
        

start1=Startup        

class Loginfirst():
    def init(self, master):

        win2 = Toplevel(self.master)
        myWIN = (win2,self)
        self.title("Leg's Name")

        self.butone = Button(self.master, text="Create Account", command=self.makeit)
        self.butone.place(x=400, y=200)

        self.buttwo = Button(self.master, text="Login", command=self.useit)
        self.buttwo.place(x=400, y=400)

    def makeit(self):

        win3 = Toplevel(self.master)
        myWIN = (win3,self)

    def useit(self):
        self.master.destroy()

login1=Loginfirst

#start1.start(master)

def Startitoff():
    win = Tk()
    George = Startup
    start1.start(master)
    Startup()
Startitoff()
