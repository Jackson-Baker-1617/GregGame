from tkinter import *

#win = Tk()
class Loginfirst():
    def __init__(self, master):
        self.master = master
        win2 = Toplevel(self.master)
        myWIN = (win2,self)
        self.title("A game with a title to be decided later")

        self.butone = Button(self.master, text="Create Account", command=self.makeit)
        self.butone.place(x=400, y=200)

        self.buttwo = Button(self.master, text="Login", command=self.useit)
        self.buttwo.place(x=400, y=400)
        
        
    def makeit(self):

        win3 = Toplevel(self.master)
        myWIN = (win3,self)

    def useit(self):
        self.master.destroy()

class Startup():
    def __init__(self, master):
        self.master = master
        self.master.geometry("500x500")
        self.master.title("Greg's Game")
        self.master.configure(background="#5130ec")
        
        self.butone = Button(self.master, text="Start", command=self.go)
        self.butone.place(x=200, y=200)

        self.buttwo = Button(self.master, text="Continue", command=self.keep)
        self.buttwo.place(x=200, y=300)
        self.buttwo = Button(self.master, text="Quit", command=self.stop)
        self.buttwo.place(x=200, y=400)

    def go(master):
        login1=Loginfirst
        login1(master)
    def keep(self):
        self.master.destroy()
    def stop(self):
        self.master.destroy()
def main():
    win=Tk()
    start1=Startup(win)
main()
#activebackround="#c16139", activeforeground="#5130ec",    
##start1=Startup
##start1.start()
##
##class Loginfirst():
##    def __init__(self, master):
##        self.master = master
##        win2 = Toplevel(self.master)
##        myWIN = (win2,self)
##        self.title("A game with a title to be decided later")
##
##        self.butone = Button(self.master, text="Create Account", command=self.makeit)
##        self.butone.place(x=400, y=200)
##
##        self.buttwo = Button(self.master, text="Login", command=self.useit)
##        self.buttwo.place(x=400, y=400)
##
##    def makeit(self):
##
##        win3 = Toplevel(self.master)
##        myWIN = (win3,self)
##
##    def useit(self):
##        self.master.destroy()
