from tkinter import *
import wikipedia
import google

class Makeit3():
    def __init__(self, master):
    #password choice
            self.master = master
            self.master.geometry("1920x1080")
            self.master.configure(background="#5130ec")
            self.master.title("Dont make it Greg Greg Greg")
            
            win5 = Toplevel(self.master)
            myWIN = (win5,self.master)

            self.master.passlable = Entry(self.master, text="Passowrd", bg = "#b50021")
            self.master.passlable.place(x=150, y=600)

            self.master.passname = Entry(self.master, textvariable=self.passname, bg = "1a7a90")
            self.master.passname.place(x=150, y=700)

            self.master.userlable = Entry(self.master, command=Savingfiles3, text = "Enter")
            self.master.userlable.place(x=150, y=400)
    def Savingfiles3(self,master):
    #should save and open next screen
            with open (textname, "a+") as file:
                file.write(passname.lower()+"\n")
class Makeit2():
    def __init__(self, master):
    #username choice
            self.master = master
            self.master.geometry("1920x1080")
            self.master.configure(background="#5130ec")
            self.master.title("Dont make it Greg Greg Greg")
            
            win4 = Toplevel(self.master)
            myWIN = (win4,self.master)

            self.master.userlable = Entry(self.master, text = "UserName")
            self.master.userlable.place(x=150, y=400)

            self.master.username = Entry(self.master, textvariable=self.master.username, bg = "1a7a90")
            self.master.username.place(x=150, y=500)

            self.master.userlable = Entry(self.master, command=Savingfiles2, text = "Enter")
            self.master.userlable.place(x=150, y=400)

            
    def Savingfiles2(self,master):
        #should save and open next screen
            with open (textname, "a+") as file:
                file.write(username.lower()+"\n")
            win5 = Toplevel(self.master)
            myWIN = Makeit3(win5)
class Makeit():
    def __init__(self, master):
        #file name coice
            self.master = master
            self.master.geometry("1920x1080")
            self.master.configure(background="#5130ec")
            self.master.title("Dont make it Greg Greg Greg")
            
            win3 = Toplevel(self.master)
            myWIN = (win3,self.master)

            self.butfive = Button(self.master, text="Save Name")
            self.butfive.place(relx=0.4, rely=0.4, anchor=N)

            self.filename = Entry(self.master, textvariable=self.filename, bg = "1a7a90")
            self.filename.place(relx=0.5, rely=0.5, anchor=CENTER)

            self.butfour = Button(self.master, text="Enter", command=Savingfiles)
            self.butfour.place(relx=0.6, rely=0.6, anchor=s)

    def Savingfiles(self):
    #should save and open next screen
        self.master.Savefile=filename+".txt"
        win4 = Toplevel(self.master)
        myWIN = Makeit2(win4)

class Login():
    def __init__(self, master):
    #account screen
        self.master = master
        self.master.geometry("1920x1080")
        self.master.configure(background="#5130ec")
        self.master.title("A game with a title to be decided later")

        self.butone = Button(self.master, text="Create Account", command=self.makeit)
        self.butone.place(relx=0.497, rely=0.4, anchor=CENTER)

        self.buttwo = Button(self.master, text="Login", command=self.useit)
        self.buttwo.place(relx=0.5, rely=.6, anchor=S)
       
    def makeit(self):
    #lets you make an account
        win3 = Toplevel(self.master)
        myWIN = Makeit(win3)
    def useit(self):
    #redirects to login once made
        self.master.destroy()

class Startup():
    def __init__(self, master):
    #load screen
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Greg's Game")
        self.master.configure(background="#5130ec")

        self.path = PhotoImage(file = "Users/jacksonbaker/Desktop/greggame/Images/Logo")
        self.canvas = Canvas(self.master, width = 675, height = 675)
        self.canvas.image = self.path

        self.canvas.create_image(image = self.path, anchor = NW)
        
        self.butone = Button(self.master, text="Start", command=self.go)
        self.butone.place(relx=0.5, rely=0.5, anchor=N)

        self.buttwo = Button(self.master, text="Continue", command=self.keep)
        self.buttwo.place(relx=0.498, rely=0.6, anchor=CENTER)

        self.butthree = Button(self.master, text="Quit", command=self.stop)
        self.butthree.place(relx=0.5, rely=0.7, anchor=S)

    def go(self):
    #opens save creator
        win2 = Toplevel(self.master)
        myWIN = Login(win2)
    def keep(self):
    #temporarily useless, will load files
        self.master.destroy()
    def stop(self):
    #stops the code
        self.master.destroy()
def main():
    #to start the code
    win=Tk()
    start1=Startup(win)
#actually running it
main()





#activebackround="#c16139", activeforeground="#5130ec",    
##start1=Startup
##start1.start()
##
##class Loginfirst():
##    def __init__(self, master):
##        self.master = master
##        win2 = Toplevel(self.master)
##        myWIN = (win2,self)
##        self.title("A game with a title to be decided later")
##
##        self.butone = Button(self.master, text="Create Account", command=self.makeit)
##        self.butone.place(x=400, y=200)
##
##        self.buttwo = Button(self.master, text="Login", command=self.useit)
##        self.buttwo.place(x=400, y=400)
##
##    def makeit(self):
##
##        win3 = Toplevel(self.master)
##        myWIN = (win3,self)
##
##    def useit(self):
##        self.master.destroy()

##class Makeit(self, master):
##    def __init__(self, master):
##            self.master = master
##            self.master.geometry("1920x1080")
##            self.master.title("Making Account")
##            
##            win3 = Toplevel(self.master)
##            myWIN = (win3,self.master)
##
##            self.master.filelable = Entry(self.master, text = "Save File Name", bg = "#b50021")
##            self.master.filelable.place(x=150, y=50)
##
##            self.master.filename = Entry(self.master, textvariable=self.master.filename, bg = "1a7a90")
##            self.master.filename.place(x=150, y=50)
##
##            self.master.userlable = Entry(self.master, text = "Name", bg = "#b50021")
##            self.master.userlable.place(x=150, y=50)
##
##            self.master.username = Entry(self.master, textvariable=self.master.username, bg = "1a7a90")
##            self.master.username.place(x=150, y=50)
##
##            self.master.passlable = Entry(self.master, text="Passowrd", bg = "#b50021")
##            self.master.passlable.place(x=150, y=50)
##
##            self.master.passname = Entry(self.master, textvariable=self.master.passname, bg = "1a7a90")
##            self.master.passname.place(x=150, y=50)
##
##
##            self.master.Savefile=filename+".txt"

#   win.attributes('-fullscreen', True)

##        self.master = master
##        self.master.geometry("1920x1080")
##        self.master.title("Making Account")
##        
##        win3 = Toplevel(self.master)
##        myWIN = (win3,self.master)
##
##        self.master.filelable = Entry(self.master, text = "Save File Name", bg = "#b50021")
##        self.master.filelable.place(x=150, y=50)
##
##        self.master.filename = Entry(self.master, textvariable=self.master.filename, bg = "1a7a90")
##        self.master.filename.place(x=150, y=50)
##
##        self.master.userlable = Entry(self.master, text = "Name", bg = "#b50021")
##        self.master.userlable.place(x=150, y=50)
##
##        self.master.username = Entry(self.master, textvariable=self.master.username, bg = "1a7a90")
##        self.master.username.place(x=150, y=50)
##
##        self.master.passlable = Entry(self.master, text="Passowrd", bg = "#b50021")
##        self.master.passlable.place(x=150, y=50)
##
##        self.master.passname = Entry(self.master, textvariable=self.master.passname, bg = "1a7a90")
##        self.master.passname.place(x=150, y=50)
##
##
##        self.master.Savefile=filename+".txt"
##

#       with open (filename, "a+") as file:
 
##        self.master.filelable = Entry(self.master, text = "Save File Name", bg = "#b50021")
##
##        self.master.filename = Entry(self.master, textvariable=self.master.filename, bg = "1a7a90")
##
##        self.master.userlable = Entry(self.master, command=Savingfiles3, text = "Enter")                   

#win = Tk()

##            self.master.userlable = Entry(self.master, text = "Name", bg = "#b50021")
##            self.master.userlable.place(x=150, y=400)
##
##            self.master.username = Entry(self.master, textvariable=self.master.username, bg = "1a7a90")
##            self.master.username.place(x=150, y=500)
##
##            self.master.passlable = Entry(self.master, text="Passowrd", bg = "#b50021")
##            self.master.passlable.place(x=150, y=600)
##
##            self.master.passname = Entry(self.master, textvariable=self.master.passname, bg = "1a7a90")
##            self.master.passname.place(x=150, y=700)
