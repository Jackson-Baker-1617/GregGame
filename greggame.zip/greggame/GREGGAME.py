from tkinter import *

#win = Tk()
class Login():
    def __init__(self, master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.configure(background="#5130ec")
        self.master.title("A game with a title to be decided later")

        self.butone = Button(self.master, text="Create Account", command=self.makeit)
        self.butone.place(relx=0.497, rely=0.4, anchor=CENTER)

        self.buttwo = Button(self.master, text="Login", command=self.useit)
        self.buttwo.place(relx=0.5, rely=.6, anchor=S)
        
        
    def makeit(self, master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Making Account")
        
        win3 = Toplevel(self.master)
        myWIN = (win3,self.master)

        self.master.filelable = Entry(self.master, text = "Save File Name", bg = "#b50021")
        self.master.filelable.place(x=150, y=50)

        self.master.filename = Entry(self.master, textvariable=self.master.filename, bg = "1a7a90")
        self.master.filename.place(x=150, y=50)

        self.master.userlable = Entry(self.master, text = "Name", bg = "#b50021")
        self.master.userlable.place(x=150, y=50)

        self.master.username = Entry(self.master, textvariable=self.master.username, bg = "1a7a90")
        self.master.username.place(x=150, y=50)

        self.master.passlable = Entry(self.master, text="Passowrd", bg = "#b50021")
        self.master.passlable.place(x=150, y=50)

        self.master.passname = Entry(self.master, textvariable=self.master.passname, bg = "1a7a90")
        self.master.passname.place(x=150, y=50)


        self.master.Savefile=filename+".txt"

 #       with open (filename, "a+") as file:
            

    def useit(self):
        self.master.destroy()

class Startup():
    def __init__(self, master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Greg's Game")
        self.master.configure(background="#5130ec")
        
        self.butone = Button(self.master, text="Start", command=self.go)
        self.butone.place(relx=0.5, rely=0.5, anchor=N)

        self.buttwo = Button(self.master, text="Continue", command=self.keep)
        self.buttwo.place(relx=0.498, rely=0.6, anchor=CENTER)

        self.butthree = Button(self.master, text="Quit", command=self.stop)
        self.butthree.place(relx=0.5, rely=0.7, anchor=S)

    def go(self):
        win2 = Toplevel(self.master)
        myWIN = Login(win2)
    def keep(self):
        self.master.destroy()
    def stop(self):
        self.master.destroy()
def main():
    win=Tk()
    start1=Startup(win)
main()
#activebackround="#c16139", activeforeground="#5130ec",    
##start1=Startup
##start1.start()
##
##class Loginfirst():
##    def __init__(self, master):
##        self.master = master
##        win2 = Toplevel(self.master)
##        myWIN = (win2,self)
##        self.title("A game with a title to be decided later")
##
##        self.butone = Button(self.master, text="Create Account", command=self.makeit)
##        self.butone.place(x=400, y=200)
##
##        self.buttwo = Button(self.master, text="Login", command=self.useit)
##        self.buttwo.place(x=400, y=400)
##
##    def makeit(self):
##
##        win3 = Toplevel(self.master)
##        myWIN = (win3,self)
##
##    def useit(self):
##        self.master.destroy()
