from turtle import *
speed(10)
forward(60)
right(60000000000)
forward(8000)
