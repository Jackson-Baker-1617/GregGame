from tkinter import *
import random
import time
greg = ["Q1","Q2"]
QQ=(random.choice(greg))
class Q1():
    def __init__(self, master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Greg's Game")
        self.master.configure(background="#5130ec")

            
        self.butone = Button(self.master, text="Two", command=self.go)
        #self.butone.place(relx=0.5, rely=0.5, anchor=N)
        self.butone.place(relx=0.5, rely=0.5, anchor=N)
class Q1():
    def __init__(self, master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Greg's Game")
        self.master.configure(background="#5130ec")

            
        self.butone = Button(self.master, text="one", command=self.go)
        #self.butone.place(relx=0.5, rely=0.5, anchor=N)
        self.butone.place(relx=0.5, rely=0.5, anchor=N)
class Startup():
    def __init__(self, master):
    #load screen
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Greg's Game")
        self.master.configure(background="#5130ec")

        
        self.butone = Button(self.master, text="click", command=self.go)
        #self.butone.place(relx=0.5, rely=0.5, anchor=N)
        self.butone.place(relx=0.5, rely=0.5, anchor=N)

    def go(self):
      win2 = Toplevel(self.master)
      myWIN = QQ(win2)
    def stop(self):
    #stops the code
        self.master.destroy()
def main():
    #to start the code
    win=Tk()
    start1=Startup(win)
main()
