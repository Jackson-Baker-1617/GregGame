from turtle import *
import random
import time
baltic = ["russia","ukraine","belarus","uzbekistan","kazakhstan","georgia","azerbaijan","lithuania","moldova","latvia","kyrgyzstan","tajikistan","armenia","turkmenistan","estonia"]
b1=(random.choice(baltic))
b2=(random.choice(baltic))
b3=(random.choice(baltic))
b4=(random.choice(baltic))
b5=(random.choice(baltic))
b6=(random.choice(baltic))
b7=(random.choice(baltic))
b8=(random.choice(baltic))
b9=(random.choice(baltic))
b10=(random.choice(baltic))
print(b1,b2,b3,b4,b5,b6,b7,b8,b9,b10)
def first():
    start=input("play game?(y/n)")
    if start.lower()=="y":
            game()
    elif start.lower()=="n":
            print ("You moist golfball")
def game():
    print("guess the former USSR states with no hints until you eventually lose(or reach maximum score of 10)")
    a1=input("first state")
    if a1.lower()==b1:
        a2=input("next state")
        if a2.lower()==b2:
            a3=input("next state")
            if a3.lower()==b3:
                  print("congrats") 
            else:
                print ("You moist golfball")
        else:
            print ("You moist golfball")
    else:
        print ("You moist golfball")

first()
