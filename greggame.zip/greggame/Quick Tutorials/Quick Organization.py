from turtle import *


#creates the game board
def board():
    print("This code would draw out the tic tac toe board")


#decides if an X or an O should be placed
def whoseturn(turn):
    print("This code would change the player's turn")
    turn=turn+1
    print(turn)
    return turn

#checks to see if there are any winners yet
def winnerwinner():
    print("This code would check to see if anyone has won")



#the main program that pulls it all together
def main():
    turn=1  #creating a variable to determine whose turn it is
    play=input("Do you want to play Tic Tac Toe? ")
    if play.upper()=="Y":
        board()
    while play.upper()=="Y":
        move=input("Where do you want to make your move? ")
        turn=whoseturn(turn)
        if turn<9:
            print("Next player's turn")
        else:
            play="n"
        winnerwinner()
    print("Thanks for playing, see you next time")

main()
