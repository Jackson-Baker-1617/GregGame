
start=input("Do you want to hear a story? (Y/N)")
while start=="Y":
  answer1=input("What do you want to do?(Run, Skip or Jump)")
  if answer1.upper()=="RUN":
    print("Run, Forrest, Run!")
    answer2=int(input("How far do you want to run?"))
    if answer2 < 3:
      print("Forrest would never stop there...")
      start=input("Do you want to play again? (Y/N)")
    else:
      print("That seems like a decent workout")
      start=input("Do you want to play again? (Y/N)")
  elif answer1.upper()=="SKIP":
    print("Never a bad idea.")
    start=input("Do you want to play again? (Y/N)")
  elif answer1.upper()=="JUMP":
    print("Jump, everybody, jump!")
    start=input("Do you want to play again? (Y/N)")
  else:
    print("You need to choose one of the options given!!")
print("Well that's no fun")
