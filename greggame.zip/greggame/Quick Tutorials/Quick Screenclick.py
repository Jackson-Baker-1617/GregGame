from tkinter import *


class HomePage():
    def __init__(self, master):
        self.master=master
        
        self.canvas = Canvas(self.master, width=100, height=100)
        self.canvas.bind("<Button-1>", self.callback) #binds the clicking of "Button-1" on the mouse to the function called "callback"
        self.canvas.pack()
        
    def callback(self,event): #this function is called because of an event (the button click)
        print ("clicked at", event.x, event.y) #from the event (the button click), grab the x and y value




def main():
    win = Tk()
    startup=HomePage(win)

main()
