from tkinter import *



class HomePage():
    def __init__(self, master):
        #sets the window details
        self.master=master
        self.master.title("Move it, move it!")
        self.master.geometry("800x800+400+400")

        #creates a canvas for the images to be placed
        self.canvas = Canvas(self.master, width=800, height=800, bg="powder blue")
        self.canvas.grid(row=0, column=0)

        #assigns the keys on the keyboard that will move the objects
        self.canvas.bind_all("a", self.rectmoveleft)
        self.canvas.bind_all("s", self.rectmoveright)
        self.canvas.bind_all("w", self.rectmoveup)
        self.canvas.bind_all("d", self.rectmovedown)
        self.canvas.bind_all("<Left>", self.circmoveleft)
        self.canvas.bind_all("<Right>", self.circmoveright)
        self.canvas.bind_all("<Up>", self.circmoveup)
        self.canvas.bind_all("<Down>", self.circmovedown)

        #creates the shapes that will be moved
        self.circle=self.canvas.create_oval(700,40,750,90, outline="blue", fill="red")
        self.rectangle=self.canvas.create_rectangle(0,0,50,50, outline="red", fill="blue")

    #creates the function that will get the coordinates of the shapes' location
    def box_coords(self):
        rect = self.canvas.bbox(self.rectangle) #bbox=boundary box
        #The next four lines take each coordinate from the boundary box of the rectangle and assigns them their own variable
        self.rx1 = rect[0]
        self.ry1 = rect[1]
        self.rx2 = rect[2]
        self.ry2 = rect[3]

        #Same thing for the circles boundary box coordinates
        circ = self.canvas.bbox(self.circle)
        self.cx1 = circ[0]
        self.cy1 = circ[1]
        self.cx2 = circ[2]
        self.cy2 = circ[3]
        

    def rectmoveleft(self,arg):
        #calls the coordinates function to figure out where each shape is
        self.box_coords()

        #moves the rectangle to the left, 5 pixels at a time
        self.canvas.move(self.rectangle, -5, 0)  
        self.master.update()
        self.master.after(30)

        #checks for a collision - if the rectangle's left side (rx1) is between the circle's x and y values, print "ouch"
        if self.cx1 <= self.rx1 <= self.cx2 and self.cy1 <= self.ry1 <= self.cy2:
            print ("ouch")

        
    def rectmoveright(self,arg):
        self.box_coords()
        self.canvas.move(self.rectangle, 5, 0)
        self.master.update()
        self.master.after(30)
        if self.cx1 <= self.rx2 <= self.cx2 and self.cy1 <= self.ry1 <= self.cy2:
            print ("ouch")
        
    def rectmovedown(self,arg):
        self.box_coords()
        self.canvas.move(self.rectangle, 0, 5)
        self.master.update()
        self.master.after(30)
        if self.cy1 <= self.ry2 <= self.cy2 and self.cx1 <= self.rx1 <= self.cx2:
            print ("ouch")
        
    def rectmoveup(self,arg):
        self.box_coords()
        self.canvas.move(self.rectangle, 0, -5)
        self.master.update()
        self.master.after(30)
        if self.cy1 <= self.ry1 <= self.cy2 and self.cx1 <= self.rx1 <= self.cx2:
            print ("ouch")

            
    def circmoveleft(self,arg): #NOTE: Collision is only checked when the rectangle is being moved, not the circle
        self.canvas.move(self.circle, -5, 0)
        self.master.update()
        self.master.after(1)
        
    def circmoveright(self,arg):
        self.canvas.move(self.circle, 5, 0)
        self.master.update()
        self.master.after(30)
        
    def circmoveup(self,arg):
        self.canvas.move(self.circle, 0, -5)
        self.master.update()
        self.master.after(30)
        
    def circmovedown(self,arg):
        self.canvas.move(self.circle, 0, 5)
        self.master.update()
        self.master.after(30)
            


def main():
    win=Tk()
    mywelcome = HomePage(win)

main()


    
