def write():
    #asks the user for information to add (this can be anything!)
    add=input("Okay, what would you like to add to the file: ")

    #opens the text file called info.txt, allows it to be appended ("a"), and puts the info into the variable called file
    with open("info.txt", "a") as file:
        file.write(add.lower()+"\n")  #writes to the file - adds the information the user input into the text file - the "\n" adds a return at the end of the line
        print("Okay, your information has been added")


def find():
    look=input("What are you looking for in the file? ")

    #opens the text file called info.txt, only lets it be read (not changed at all), and puts the info into the variable called file
    with open("info.txt", "r") as file:
        filecontents=file.readlines() #reads each line in the file and stores them individually into the variable called filecontents
        for line in filecontents:  #checks each line in filecontents one by one
            if line.strip().lower().startswith(look.lower()): #strips extra spaces, puts everything in lowercase and checks to see if any of the lines startswith the user input
                print(line)
    

def change():
    remove=input("What line would you like to change? ")
    exchange=input("What would you like it to say? ")
    with open("info.txt", "r") as file: #reads the file
        filecontents=file.read() #stores the entire file in filecontents
    filecontents=filecontents.replace(remove+"\n",exchange+"\n") #replaces the given line with the new line
    with open("info.txt", "w") as file: #opens the file so it can be written to
        file.write(filecontents) #changes the file with the new replacement


def main():
    file=input("Hi, do you want to find info in a file, add to a file, or change a file? (F/A/C)")
    if file.upper()=="F":
        find()
    elif file.upper()=="A":
        write()
    elif file.upper()=="C":
        change()
    else:
        print("Your only choices are F, A or C.  Please choose one")
        main()

main()
