from tkinter import *



class HomePage():
    def __init__(self, master):
        self.master=master
        self.master.title("Move it, move it!")
        self.master.geometry("800x800+400+400")

        self.canvas = Canvas(self.master, width=800, height=800, bg="powder blue")
        self.canvas.grid(row=0, column=0)
        self.rectangle=self.canvas.create_rectangle(0,0,100,200, outline="red", fill="blue")

        self.canvas.bind_all("s", self.move)    #when the "s" button is clicked, go to the move definition
        

    def move(self,arg): #I haven't figured out why yet, but you need to put ,arg after self when you are using keys to move and not buttons
        for i in range(0, 100, 10): 
            self.canvas.move(self.rectangle, 5, 6)  
            self.master.update()
            self.master.after(30) 

def main():
    win=Tk()
    mywelcome = HomePage(win)

main()
