def changeinturn(turn1): #takes the result from the input in main() and passes it into this function as the variable who
    who1=turn1
    if who1=="1":
        who1="2"
    elif who1=="2":
        who1="1"
    else:
        who1=input("You need to choose 1 or 2. Try again? ")
        who1=changeinturn(who1)  #takes the result from this input and runs it back through this function
    return who1 #makes the outcome of this function available to use in other functions
    

def main():
    turn1=input("Whose turn is it? (1 or 2) " ) #creates a variable for the input
    who2=changeinturn(turn1) #plugs the answer from the input into the changeinturn function
                            # and sets the answer to the changeinturn function to the variable mine
    print ("It is the turn of player #" +who2)
    

main()
