from tkinter import*

win=Tk()

win.geometry("300x300")

def var():
    global word1 #global makes the variables available throughout the entire program
    global word2 #USE GLOBAL SPARINGLY! 
    word1=[]
    word2=[]

def buttonhello():
    display.config(text="Hello")
    word1.append("Hello")

def buttonyall():
    display.config(text="Y'all")
    word2.append("Y'all")
    
def clearbutton():
    display.config(text="")
    var() #calls the var function to reset all of the variables I created
    
def plusbutton():
    for word in word1: #grabs the value in the array called word1
        for other in word2: #grabs the value in the array called word2
            display.config(text=word+other) #adds the words together

var() #calls the var function to define all of the variables I created

display=Label(text="")
display.place(x=0, y=0)

buttonhello=Button(text="Hello", command=buttonhello)
buttonhello.place(x=50, y=50)

buttonyall=Button(text="Y'all", command=buttonyall)
buttonyall.place(x=100, y=50)

clearbutton=Button(text="clear", command=clearbutton)
clearbutton.place(x=200, y=100)

plusbutton=Button(text="+", command=plusbutton)
plusbutton.place(x=50, y=100)

