from tkinter import *

class Home():
    def __init__(self, master):
        self.master=master
        self.master.title("Timer/Game")
        self.master.geometry("200x250+800+200")

        self.master.config(bg="pink")

        global time
        time=10
        
        self.timerlabel=Label(self.master, text=time)
        self.timerlabel.place(x=100, y=100)
        
        self.timer()
        
    def timer(self):
        global time
        time=time-1
        self.timerlabel.config(text=time)
        if time <= 0:
            self.timerlabel.config(text="Sorry, time's up!")
        self.master.after(1000,self.timer)
        

def main():
    win=Tk()
    mywelcome = Home(win)
    
main()
