from random import randint
import time


def theexcitement():
    reset() #clears the board for the main event

    
    number1=randint(0,50) #a random number is chosen from 0-50 and stored in the variable number1
    pencolor("purple")
    write(number1, font=("Comic Sans",100)) #displays the random number that was chosen
    time.sleep(2) #A 2 second pause for dramatic effect

    #Displays the instructions to start over
    reset()
    penup()
    goto(-100,30)
    write("Do you want to see that again??", font=("Comic Sans", 40))
    goto(-100, -10)
    write("Go to the shell...", font=("Comic Sans", 40))

    time.sleep(1) #another dramatic pause
    reset()
    redeux() #calls the function that asks the user if they want to start over again
    

#The start over function
def redeux():
    startover=input("Do you want to see it again? How could you not?? (Y/N)")
    if startover.upper()=="Y":
        starting() #calls the starting function
    elif startover.upper()=="N":
        print("Unimpressed were you?")
    else:
        print("Please only select Y or N")
        redeux() #Goes back up to the top so they have to answer y or n
        

#Starts things off with some anticipation
def starting():
    setup(width=1800, height=1800) #sets the size of the turtle window
    
    pencolor("green")
    penup()
    goto(-100,30)
    write("Do you want to see something amazing?", font=("Comic Sans", 40))
    time.sleep(.8)
    reset()
    penup()
    goto(-100,30)
    write("Are you sure you're ready for this?", font=("Comic Sans", 40))
    time.sleep(.8)
    reset()
    penup()
    goto(-100,30)
    write("Okay, you asked for it!", font=("Comic Sans", 40))
    time.sleep(.8)
    reset()

    theexcitement()  #Calls the excitement function


starting()  #don't forget to call the first function to get things rolling
