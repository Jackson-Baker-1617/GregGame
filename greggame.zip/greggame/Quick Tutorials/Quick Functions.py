from turtle import *

#creating the definition for drawing each rectangle
def rect():
    for i in range(2):
        forward(80)
        right(90)
        forward(20)
        right(90)

#creating the definition for moving to the next rectangle
def move():
    penup()
    forward(20)
    right(90)
    forward(20)
    pendown()

#creating the definition to call the above definitions four times to create the design
def main():
    for i in range(4):
        rect()
        move()

#calling the main definition to get it all started
main()
