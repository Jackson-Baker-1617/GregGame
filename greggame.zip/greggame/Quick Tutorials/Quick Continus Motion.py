from tkinter import *

class Home():
    def __init__(self, master):
        self.master=master
        self.master.title("Continuous Movement")

        #creates global values for the movement of the object
        global xdirection
        global ydirection
        xdirection=5
        ydirection=0

        #creates the canvas
        self.canvas=Canvas(self.master, width=800,height=800, bg="light blue")
        self.canvas.pack()

        #assigns the click of a button to the definition called "changedirection"
        self.canvas.bind("<Button-1>", self.changedirection)

        #creates the rectangle
        self.square=self.canvas.create_rectangle(0,0,50,50, fill="red")

        #begins the motion of the rectangle by calling the fluid definition
        self.fluid()

        
    def fluid(self):
        #moves the rectangle based off the current value of xdirection and ydirection
        self.canvas.move(self.square, xdirection, ydirection)

        #updates the master window every 30ms and then calls the fluid function again - "perpetual motion"
        self.master.after(30, self.fluid)

    def changedirection(self, event):
        global xdirection
        global ydirection

        #gets the boundary box of the rectangle (it's current location)
        shape=self.canvas.bbox(self.square)
        self.x1 = shape[0]
        self.y1 = shape[1]
        self.x2 = shape[2]
        self.y2 = shape[3]

        #if the button click (event.x, event.y) is within the rectangle...
        if self.x1 <= event.x <= self.x2 and self.y1 <= event.y <= self.y2:
            #multiply the xdirection value by -1 to make it change direction
            xdirection = xdirection * -1
       

def main():
    win=Tk()
    startpage=Home(win)

main()
