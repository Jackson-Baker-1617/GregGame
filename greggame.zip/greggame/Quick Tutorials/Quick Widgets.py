from tkinter import *

win = Tk()      #this line creates the window that your stuff(widgets) will go in. A necessary step.


win.geometry("850x450")     #this sets the size of the window.  The first number is width, the second length.
win.title("Calculator")     #this gives your window a title

information="Hi"
#this section of code gives the computer instructions for what to do when the "OK" button is clicked
def okbutton():
    text1= "Hello"
    Label2.config(text=text1)
 

#this section of code gives the computer instructions for what to do when the "Add" button is clicked
def addbutton():
    text2=" Y'all"
    Label2.config(text=Label2.cget("text")+text2) #Label3.cget("text") gets the information that is printed in the label

def clearbutton():
    cleartext=""
    Label2.config(text=cleartext)

#This section of code just plays around with some attributes of labels
Label1 = Label(text="My Label", fg = "red", bg = "powder blue")     #fg=text color, bg=background color
Label1.place(x=50, y=75)       #if we don't give the label a location, it will not show up in the window

Label2 = Label(text=information, font=("Helvetica", 20),fg="pink", bg="black")
Label2.place(x=50, y=150)


#this section of code plays around with some attributes of buttons
okbutton = Button(text="OK", command = okbutton, height=50, width=20)  #the command calls the definition we made for the okbutton at the top of the program
okbutton.pack() #pack just puts it in order, hard to place but possible to change button size

addbutton = Button(text = "Add", command = addbutton)
addbutton.place(x=250, y=75)

clearbutton=Button(text="Clear", command=clearbutton, highlightbackground="green")
clearbutton.place(x=300,y=400)
