from tkinter import *

class HomePage():
    def __init__(self, master):
        self.master = master
        self.master.title("Home Page")

        self.path = PhotoImage(file = "spiral.gif") #The file name needs to be the whole path to wherever you saved the image. It is best practice to save your files in the same folder.
        self.canvas = Canvas(self.master, width = 675, height = 675, bg = "orange")
        self.canvas.image = self.path   #this line helps python remember the image
        self.canvas.pack(expand = YES, fill = "both")

        #the upper left corner of the image is x=50, y=10
        self.canvas.create_image(50, 10, image = self.path, anchor = NW)


        self.nextpage = Button(self.master, text = "KEEP GOING!", command = self.next, width = 8, anchor = "center", highlightbackground = "blue")
        self.nextpage.window = self.canvas.create_window(250, 600, anchor = "s", window = self.nextpage) #puts the button on the canvas/image with x=250, y=600
        
        self.done = Button(self.master, text = "QUIT", command = self.done, width = 8, anchor = "center", highlightbackground = "red")
        self.done.window = self.canvas.create_window(450, 600, anchor = "s", window = self.done)

        self.forget = Button(self.master, text="Forget this Button", command = self.forget)
        self.forget.pack()
        self.canvas.create_window(200, 600, window = self.forget)


    def forget(self):
        self.forget.pack_forget()
        
        
        
        
    def done(self):
        self.master.destroy()

    def next(self):
        win2 = Toplevel(self.master)
        myGUI=NextPage(win2)

class NextPage():
    def __init__(self, master):
        self.master = master
        self.master.title("Magic Page")
        self.master.geometry("450x450")
        self.master.configure(bg="yellow")
        self.button1 = Button(self.master, text="GO BACK HOME", command = self.back, highlightbackground = "purple")
        self.button1.pack()

    def back(self):
        self.master.destroy()
        

def main():
    win = Tk()
    myhome = HomePage(win)

main()
