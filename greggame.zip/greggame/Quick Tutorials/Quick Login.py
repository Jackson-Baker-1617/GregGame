from tkinter import*

class Login():
    def __init__(self, master):
        self.master=master
        self.master.geometry("550x550+800+800")
        self.master.title("Sign In")

        self.username = StringVar()
        self.password = StringVar()
        self.file = StringVar()
        self.line = StringVar()

        self.userlabel = Label(self.master, text = "Username", bg= "black", fg="white")
        self.userlabel.place(x=70, y=50)

        self.username = Entry(self.master, textvariable=self.username, bg = "pink")
        self.username.place(x=150, y=50)

        self.passlabel = Label(self.master, text = "Password", bg = "black", fg="white")
        self.passlabel.place(x=70, y=100)

        self.password = Entry(self.master, textvariable=self.password, bg = "yellow")
        self.password.place(x=150, y=100)

        self.login = Button(self.master, text = "Submit", highlightbackground = "red", command = self.login)
        self.login.place(x=200, y=150)

        self.register = Button(self.master, text = "New to the game? Register here!", command=self.register)
        self.register.place(x=100, y=425)

    def login(self):
        self.use = self.username.get()
        self.pword = self.password.get()
        self.file = open("registration.txt", "r")
        self.line = self.file.readlines()
        q=0
        for l in self.line:
            if l == str(self.username.get() + " " + self.password.get() + "\n"):
                q=1
                win3=Toplevel(self.master)
                myWWIN = Success(win3)
        if q==0:
            self.nopelabel = Label(self.master, text = "Invalid Username or Password", bg = "red", fg = "pink")
            self.nopelabel.place(x=130, y= 175)
        elif q==1:
            try:
                self.nopelabel.destroy()
            except AttributeError:
                pass
        self.file.close()

    def register(self):
        win2 = Toplevel(self.master)
        myWin = Register(win2)

class Success():
    def __init__(self, master):
        self.master = master
        self.master.title("Success")
        self.master.geometry("550x550+800+800")

        self.file = open("username.txt", "r")
        self.line = self.file.readlines()
        for contents in self.line:
            name = contents

        self.label = Label(self.master, text = ("Successful login! Welcome, ", name))
        self.label.pack()


class Register():
    def __init__(self, master):
        self.master = master
        self.master.title("Register Your Name Here")
        self.master.geometry("550x550+800+800")

        self.usename = StringVar()
        self.pword = StringVar()
        self.repword = StringVar()

        self.userlabel = Label(self.master, text = "Username", bg= "black", fg="white")
        self.userlabel.place(x=70, y=50)

        self.username = Entry(self.master, textvariable=self.usename, bg = "pink")
        self.username.place(x=250, y=50)

        self.passlabel = Label(self.master, text = "Password", bg = "black", fg="white")
        self.passlabel.place(x=70, y=100)

        self.password = Entry(self.master, textvariable=self.pword, bg = "yellow")
        self.password.place(x=250, y=100)

        self.repasslabel = Label(self.master, text = "Re-enter your password", bg = "black", fg="white")
        self.repasslabel.place(x=70, y=150)

        self.repassword = Entry(self.master, textvariable=self.repword, bg = "yellow")
        self.repassword.place(x=250, y=150)

        self.login = Button(self.master, text = "Submit", highlightbackground = "red", command = self.login)
        self.login.place(x=200, y=225)
        
    def login(self):
        if self.pword.get() == self.repword.get():
            with open("username.txt", "w") as self.file1:
                self.use = self.usename.get()
                self.file1.write(self.use)
            with open("registration.txt", "a") as self.file:
                self.usepass = self.usename.get() + " " + self.pword.get() + "\n" #"\n" creates a line break at the end 
                self.file.write(self.usepass)
            self.master.destroy()

def main():
    win=Tk()
    myhome = Login(win)

main()
