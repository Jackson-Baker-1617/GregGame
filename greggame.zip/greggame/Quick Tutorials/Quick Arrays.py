answer=[1,4,5] 

guessright=[]    
play=1          


print("You are going to try and guess the three numbers I am thinking about, one at a time")
while play==1:
    guess=int(input("Guess one of the numbers: "))
    if guess in answer:
        guessright.append(guess)
        if sorted(guessright)==answer:
            print("Congrats, you guessed all three numbers!")
            play=2
        else:
            print("Nice job, you guessed one of the numbers.  Keep trying.")
    else:
        print("Sorry, that isn't one of the numbers. Try again.")
