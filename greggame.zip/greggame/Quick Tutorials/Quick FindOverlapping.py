from tkinter import *



class HomePage():
    def __init__(self, master):
        #sets the window details
        self.master=master
        self.master.title("Move it, move it!")
        self.master.geometry("800x800+400+400")

        #creates a canvas for the images to be placed
        self.canvas = Canvas(self.master, width=800, height=800, bg="powder blue")
        self.canvas.grid(row=0, column=0)

        #assigns the keys on the keyboard that will move the objects
        self.canvas.bind_all("a", self.rectmoveleft)
        self.canvas.bind_all("s", self.rectmoveright)
        self.canvas.bind_all("w", self.rectmoveup)
        self.canvas.bind_all("d", self.rectmovedown)

        self.circle=self.canvas.create_oval(700,40,750,90, outline="blue", fill="red")
        self.rectangle=self.canvas.create_rectangle(0,0,50,50, outline="red", fill="blue")
        self.circle2=self.canvas.create_oval(40,700,90,750, outline="blue", fill="red")

        
    #creates the function that will get the coordinates of the shapes' location
    def box_coords(self):
        rect = self.canvas.bbox(self.rectangle) #bbox=boundary box
        #The next four lines take each coordinate from the boundary box of the rectangle and assigns them their own variable
        self.rx1 = rect[0]
        self.ry1 = rect[1]
        self.rx2 = rect[2]
        self.ry2 = rect[3]


    def rectmoveleft(self,arg):
        #calls the coordinates function to figure out where each shape is
        self.box_coords()

        #moves the rectangle to the left, 5 pixels at a time
        self.canvas.move(self.rectangle, -5, 0)  
        self.master.update()
        self.master.after(30)

        #checks for a collision - if the square overlaps with any other object, that objects id is recorded
        self.check=self.canvas.find_overlapping(self.rx1,self.ry1,self.rx2,self.ry2)
        for i in self.check:
            if i == 3 or i==1:
                print("ouch")

        
    def rectmoveright(self,arg):
        self.box_coords()
        self.canvas.move(self.rectangle, 5, 0)
        self.master.update()
        self.master.after(30)
        self.check=self.canvas.find_overlapping(self.rx1,self.ry1,self.rx2,self.ry2)
        for i in self.check:
            if i == 3 or i==1:
                print("ouch")
        
    def rectmovedown(self,arg):
        self.box_coords()
        self.canvas.move(self.rectangle, 0, 5)
        self.master.update()
        self.master.after(30)
        self.check=self.canvas.find_overlapping(self.rx1,self.ry1,self.rx2,self.ry2)
        for i in self.check:
            if i == 3 or i==1:
                print("ouch")
        
    def rectmoveup(self,arg):
        self.box_coords()
        self.canvas.move(self.rectangle, 0, -5)
        self.master.update()
        self.master.after(30)
        self.check=self.canvas.find_overlapping(self.rx1,self.ry1,self.rx2,self.ry2)
        for i in self.check:
            if i == 3 or i==1:
                print("ouch")

def main():
    win=Tk()
    start=HomePage(win)
main()
