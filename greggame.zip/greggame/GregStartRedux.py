from tkinter import *
import random
import time

class FileOneMake():
      def __init__(self, master):
            self.username = StringVar()
            self.password = StringVar()
            self.file = StringVar()
            self.line = StringVar()
            
            path = open(r"/Users/jacksonbaker/Desktop/greggame/SAVES/File1.txt") #Ned Batchelder taught r
            self.master = master
            self.master.geometry("1920x1080")
            self.master.title("Greg's Game")
            self.master.configure(background="#5130ec")
            text1= path.read().strip().split()

            self.namelabel = Label(self.master, text = "Username", bg= "#5130ec", fg = "#FF6700")
            self.namelabel.place(relx=0.5, rely=0.4, anchor=N)

            self.username = Entry(self.master, textvariable=self.username, bg = "#1a7a90")
            self.username.place(relx=0.5, rely=0.5, anchor=CENTER)

            self.passlabel = Label(self.master, text = "Password", bg= "#5130ec", fg = "#FF6700")
            self.passlabel.place(relx=0.5, rely=0.4, anchor=N)

            self.passname = Entry(self.master, textvariable=self.passname, bg = "#1a7a90")
            self.passname.place(relx=0.5, rely=0.5, anchor=CENTER)




                  
class fileOne():
      def __init__(self, master):
            self.master.username = StringVar()
            self.master.password = StringVar()
            self.master.file = StringVar()
            self.master.line = StringVar()
            
            self.master = master
            self.master.geometry("1920x1080")
            self.master.title("Greg's Game")
            self.master.configure(background="#5130ec")
              
            self.butone = Button(self.master, text="New", command=self.makeone)
            self.butone.place(relx=0.5, rely=0.5, anchor=N)

            self.buttwo = Button(self.master, text="Load", command=self.loadone)
            self.buttwo.place(relx=0.498, rely=0.6, anchor=CENTER)

      def makeone(self):
            
            win5 = Toplevel(self.master)
            myWIN = FileOneMake(win5)
      def loadone(self):
            
            win2 = Toplevel(self.master)
            myWIN = fileThree(win2)
                  
##class fileTwo():
##      path = open (r"C:\Users\Jackson\Desktop\greggame\SAVES\File2.txt")
##      text2= path.read().strip().split()
##class fileThree():
##      path = open (r "C:\Users\Jackson\Desktop\greggame\SAVES\File3.txt")
##      text2= path.read().strip().split()
class Filechoice():
    def __init__(self,master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Greg's Game")
        self.master.configure(background="#5130ec")

        self.butone = Button(self.master, text="File 1", command=self.file1)
        self.butone.place(relx=0.5, rely=0.5, anchor=N)

        self.buttwo = Button(self.master, text="File 2", command=self.file2)
        self.buttwo.place(relx=0.498, rely=0.6, anchor=CENTER)

        self.butthree = Button(self.master, text="File 3", command=self.file3)
        self.butthree.place(relx=0.5, rely=0.7, anchor=S)

    def file1(self):
        win3 = Toplevel(self.master)
        myWIN = fileOne(win3)
    def file2(self):
        win3 = Toplevel(self.master)
        myWIN = fileTwo(win3)
    def file3(self):
        win3 = Toplevel(self.master)
        myWIN = fileThree(win3)

class Startup():
    def __init__(self, master):
    #load screen
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Greg's Game")
        self.master.configure(background="#5130ec")

        
        self.butone = Button(self.master, text="Start", command=self.go)
        #self.butone.place(relx=0.5, rely=0.5, anchor=N)
        self.butone.place(relx=0.5, rely=0.5, anchor=N)


        self.butthree = Button(self.master, text="Quit", command=self.stop)
        self.butthree.place(relx=0.5, rely=0.7, anchor=S)

    def go(self):
    #opens save creator
      win2 = Toplevel(self.master)
      myWIN = Filechoice(win2)
    def stop(self):
    #stops the code
        self.master.destroy()
def main():
    #to start the code
    win=Tk()
    start1=Startup(win)
#actually running it
main()
