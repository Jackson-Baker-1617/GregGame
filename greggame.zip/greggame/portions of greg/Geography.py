from tkinter import *
class noweak():
    def __init__(self,master):
        self.master.geometry("1920x1080")
        self.master.title("Wrong")
        self.master.configure(background="#5130ec")

        self.filelabel = Label(self.master, text = "How do you even get this wrong? Restart from beggining coward.", bg= "#5130ec", fg = "#FF6700")
        self.filelabel.place(relx=0.5, rely=0.6, anchor=N)
        
        self.butone = Button(self.master, text="Restart", command=self.rego)
        self.butone.place(relx=0.5, rely=0.5, anchor=N)
    def rego(self):
        win300 = Toplevel(self.master)
        myWIN = Weakling(win2)
class Weakling():
    def __init__(self,master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Question 1 Weakling")
        self.master.configure(background="#5130ec")

        self.path = PhotoImage(file = "/Users/jacksonbaker/Desktop/USA.gif")
        self.canvas = Canvas(self.master, width = 675, height = 675, bg = "#0899e1")
        self.canvas.image = self.path
        self.canvas.pack(expand = YES, fill = "both")
        

        self.canvas.create_image(960, 0, image = self.path, anchor = N)

        self.filelabel = Label(self.master, text = "Question #1, what nation is this?", bg= "#0899e1", fg = "#FF6700",font=("Courier", 25))
        self.filelabel.place(relx=0.5, rely=0.6, anchor=N)
        
        self.butone = Button(self.master, text="Russia", command=self.no)
        self.butone.place(relx=0.33, rely=0.7, anchor=N)

        self.buttwo = Button(self.master, text="San Marino", command=self.no)
        self.buttwo.place(relx=0.66, rely=0.7, anchor=CENTER)

        self.butthree = Button(self.master, text="Rome", command=self.no)
        self.butthree.place(relx=0.33, rely=0.8, anchor=S)

        self.butfour = Button(self.master, text="The United States", command=self.Q2)
        self.butfour.place(relx=0.66, rely=0.8, anchor=S)
        

    def Q2(self):
        self.path = PhotoImage(file = "/Users/jacksonbaker/Desktop/China.gif")
        self.canvas = Canvas(self.master, width = 675, height = 675, bg = "#0899e1")
        self.canvas.image = self.path
        self.canvas.pack(expand = YES, fill = "both")
        

        self.canvas.create_image(960, 0, image = self.path, anchor = N)

        self.filelabel = Label(self.master, text = "Question #2, what nation is this?", bg= "#0899e1", fg = "#FF6700",font=("Courier", 25))
        self.filelabel.place(relx=0.5, rely=0.6, anchor=N)
        
        self.butone = Button(self.master, text="People's Republic of China", command=self.Q3)
        self.butone.place(relx=0.33, rely=0.7, anchor=N)

        self.buttwo = Button(self.master, text="Canada", command=self.no)
        self.buttwo.place(relx=0.66, rely=0.7, anchor=CENTER)

        self.butthree = Button(self.master, text="Greece", command=self.no)
        self.butthree.place(relx=0.33, rely=0.8, anchor=S)

        self.butfour = Button(self.master, text="The United States", command=self.no)
        self.butfour.place(relx=0.66, rely=0.8, anchor=S)
    def Q3(self):
        self.master.destroy()
    def no(self):
        win219 = Toplevel(self.master)
        myWIN = noweak(win2)




        
        
    
        
        
        
        
class start():
    def __init__(self,master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Geography Quiz")
        self.master.configure(background="#5130ec")

        self.filelabel = Label(self.master, text = "Geography Quiz", bg= "#5130ec", fg = "#FF6700",font=("Courier", 44))
        self.filelabel.place(relx=0.5, rely=0.3, anchor=N)
        
        self.butthree = Button(self.master, text="Weaking (World Powers)", command=self.weak)
        self.butthree.place(relx=0.5, rely=0.49, anchor=S)
        
        self.butone = Button(self.master, text="Easy (Modern Nations)", command=self.easy)
        self.butone.place(relx=0.5, rely=0.5, anchor=N)

        self.buttwo = Button(self.master, text="Medium (Federal Devisions)", command=self.medium)
        self.buttwo.place(relx=0.498, rely=0.55, anchor=CENTER)

        self.butthree = Button(self.master, text="Hard (Historical Organizations)", command=self.hard)
        self.butthree.place(relx=0.5, rely=0.6, anchor=S)

        self.butthree = Button(self.master, text="Godly (City States and Other Difficult)", command=self.God)
        self.butthree.place(relx=0.5, rely=0.637, anchor=S)

    def easy(self):
        win2 = Toplevel(self.master)
        myWIN = Easy(win2)
    def medium(self):
        win2 = Toplevel(self.master)
        myWIN = Medium(win2)
    def hard(self):
        win2 = Toplevel(self.master)
        myWIN = Hard(win2)
    def weak(self):
        win2 = Toplevel(self.master)
        myWIN = Weakling(win2)
    def God(self):
        win2 = Toplevel(self.master)
        myWIN = Godly(win2)


def main():
    #to start the code
    win=Tk()
    start5=start(win)       

main()
        
