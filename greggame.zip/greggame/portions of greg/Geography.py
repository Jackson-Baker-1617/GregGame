from tkinter import *
#MEDIUM DIFFUCULTY
class Easyending():
    def __init__(self,master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Nice!")
        self.master.configure(background="#b50021")

        self.filelabel = Label(self.master, text = "A bit more Difficult, Good Job, Now go HARDER", bg= "#b50021", fg = "#FF6700")
        self.filelabel.place(relx=0.5, rely=0.6, anchor=N)
        
        self.butone = Button(self.master, text="Menu", command=self.rego)
        self.butone.place(relx=0.5, rely=0.5, anchor=N)
    def rego(self):
        win6 = Toplevel(self.master)
        myWIN = start(win6)
class EasyQ5():
    def __init__(self,master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Question 5 Easy")
        self.master.configure(background="#5130ec")

        self.path = PhotoImage(file = "/Users/jacksonbaker/Desktop/Denmark.gif")
        self.canvas = Canvas(self.master, width = 675, height = 675, bg = "#b50021")
        self.canvas.image = self.path
        self.canvas.pack(expand = YES, fill = "both")
        

        self.canvas.create_image(960, 0, image = self.path, anchor = N)

        self.filelabel = Label(self.master, text = "Question #5, what nation is this?", bg= "#b50021", fg = "#FF6700",font=("Courier", 25))
        self.filelabel.place(relx=0.5, rely=0.6, anchor=N)
        
        self.butone = Button(self.master, text="Sweden", command=self.no)
        self.butone.place(relx=0.33, rely=0.7, anchor=N)

        self.buttwo = Button(self.master, text="Denmark", command=self.Easyend)
        self.buttwo.place(relx=0.66, rely=0.7, anchor=CENTER)

        self.butthree = Button(self.master, text="Norway", command=self.no)
        self.butthree.place(relx=0.33, rely=0.8, anchor=S)

        self.butfour = Button(self.master, text="Finland", command=self.no)
        self.butfour.place(relx=0.66, rely=0.8, anchor=S)
    def Easyend(self):
        win6 = Toplevel(self.master)
        myWIN = Easyending(win6)
    def no(self):
        win219 = Toplevel(self.master)
        myWIN = noeasy(win219)
class EasyQ4():
    def __init__(self,master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Question 4 Weakling")
        self.master.configure(background="#5130ec")

        self.path = PhotoImage(file = "/Users/jacksonbaker/Desktop/Isreal.gif")
        self.canvas = Canvas(self.master, width = 675, height = 675, bg = "#b50021")
        self.canvas.image = self.path
        self.canvas.pack(expand = YES, fill = "both")
        

        self.canvas.create_image(960, 0, image = self.path, anchor = N)

        self.filelabel = Label(self.master, text = "Question #4, what nation is this?", bg= "#b50021", fg = "#FF6700",font=("Courier", 25))
        self.filelabel.place(relx=0.5, rely=0.6, anchor=N)
        
        self.butone = Button(self.master, text="Isreal", command=self.Q5)
        self.butone.place(relx=0.33, rely=0.7, anchor=N)

        self.buttwo = Button(self.master, text="Palestine", command=self.no)
        self.buttwo.place(relx=0.66, rely=0.7, anchor=CENTER)

        self.butthree = Button(self.master, text="Syria", command=self.no)
        self.butthree.place(relx=0.33, rely=0.8, anchor=S)

        self.butfour = Button(self.master, text="Jordan", command=self.no)
        self.butfour.place(relx=0.66, rely=0.8, anchor=S)
    def Q5(self):
        win6 = Toplevel(self.master)
        myWIN = EasyQ5(win6)
    def no(self):
        win219 = Toplevel(self.master)
        myWIN = noeasy(win219)
class EasyQ3():
    def __init__(self,master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Question 3 Easy")
        self.master.configure(background="#5130ec")

        self.path = PhotoImage(file = "/Users/jacksonbaker/Desktop/Nicaragua.gif")
        self.canvas = Canvas(self.master, width = 675, height = 675, bg = "#b50021")
        self.canvas.image = self.path
        self.canvas.pack(expand = YES, fill = "both")
        

        self.canvas.create_image(960, 0, image = self.path, anchor = N)

        self.filelabel = Label(self.master, text = "Question #3, what nation is this?", bg= "#b50021", fg = "#FF6700",font=("Courier", 25))
        self.filelabel.place(relx=0.5, rely=0.6, anchor=N)
        
        self.butone = Button(self.master, text="Nicaragua", command=self.Q4)
        self.butone.place(relx=0.33, rely=0.7, anchor=N)

        self.buttwo = Button(self.master, text="Mexico", command=self.no)
        self.buttwo.place(relx=0.66, rely=0.7, anchor=CENTER)

        self.butthree = Button(self.master, text="Cuba", command=self.no)
        self.butthree.place(relx=0.33, rely=0.8, anchor=S)

        self.butfour = Button(self.master, text="Panama", command=self.no)
        self.butfour.place(relx=0.66, rely=0.8, anchor=S)
    def Q4(self):
        win6 = Toplevel(self.master)
        myWIN = EasyQ4(win6)
    def no(self):
        win219 = Toplevel(self.master)
        myWIN = noeasy(win219)
class EasyQ2():
    def __init__(self,master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Question 2 Easy")
        self.master.configure(background="#5130ec")

        self.path = PhotoImage(file = "/Users/jacksonbaker/Desktop/Peru.gif")
        self.canvas = Canvas(self.master, width = 675, height = 675, bg = "#b50021")
        self.canvas.image = self.path
        self.canvas.pack(expand = YES, fill = "both")
        

        self.canvas.create_image(960, 0, image = self.path, anchor = N)

        self.filelabel = Label(self.master, text = "Question #2, what nation is this?", bg= "#b50021", fg = "#FF6700",font=("Courier", 25))
        self.filelabel.place(relx=0.5, rely=0.6, anchor=N)
        
        self.butone = Button(self.master, text="Nicaragua", command=self.no)
        self.butone.place(relx=0.33, rely=0.7, anchor=N)

        self.buttwo = Button(self.master, text="Argentina", command=self.no)
        self.buttwo.place(relx=0.66, rely=0.7, anchor=CENTER)

        self.butthree = Button(self.master, text="Brazil", command=self.no)
        self.butthree.place(relx=0.33, rely=0.8, anchor=S)

        self.butfour = Button(self.master, text="Peru", command=self.Q3)
        self.butfour.place(relx=0.66, rely=0.8, anchor=S)
    def Q3(self):
        win6 = Toplevel(self.master)
        myWIN = EasyQ3(win6)
    def no(self):
        win219 = Toplevel(self.master)
        myWIN = noeasy(win219)
class noeasy():
    def __init__(self,master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Wrong")
        self.master.configure(background="#b50021")

        self.filelabel = Label(self.master, text = "This was A bit harder, But still no Mercy. Back To the Beggining With You.", bg= "#5130ec", fg = "#FF6700")
        self.filelabel.place(relx=0.5, rely=0.6, anchor=N)
        
        self.butone = Button(self.master, text="Restart", command=self.rego)
        self.butone.place(relx=0.5, rely=0.5, anchor=N)
    def rego(self):
        win300 = Toplevel(self.master)
        myWIN = Easy(win300)
class Medium():
    def __init__(self,master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Question 1 Medium")
        self.master.configure(background="#5130ec")

        self.path = PhotoImage(file = "/Users/jacksonbaker/Desktop/Albania.gif")
        self.canvas = Canvas(self.master, width = 675, height = 675, bg = "#9a9c10")
        self.canvas.image = self.path
        self.canvas.pack(expand = YES, fill = "both")
        

        self.canvas.create_image(960, 0, image = self.path, anchor = N)

        self.filelabel = Label(self.master, text = "Question #1, what nation is this?", bg= "#9a9c10", fg = "#FF6700",font=("Courier", 25))
        self.filelabel.place(relx=0.5, rely=0.6, anchor=N)
        
        self.butone = Button(self.master, text="Serbia", command=self.no)
        self.butone.place(relx=0.33, rely=0.7, anchor=N)

        self.buttwo = Button(self.master, text="Albania", command=self.Q2re)
        self.buttwo.place(relx=0.66, rely=0.7, anchor=CENTER)

        self.butthree = Button(self.master, text="Romania", command=self.no)
        self.butthree.place(relx=0.33, rely=0.8, anchor=S)

        self.butfour = Button(self.master, text="Slovenia", command=self.no)
        self.butfour.place(relx=0.66, rely=0.8, anchor=S)
        
    def Q3(self):
        self.master.destroy()
    def Q2re(self):
        win6 = Toplevel(self.master)
        myWIN = MedQ2(win6)
    def no(self):
        win219 = Toplevel(self.master)
        myWIN = nomed(win219)
#END OF MEDIUM
#Easy Difficulty
class Easyending():
    def __init__(self,master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Nice!")
        self.master.configure(background="#b50021")

        self.filelabel = Label(self.master, text = "A bit more Difficult, Good Job, Now go HARDER", bg= "#b50021", fg = "#FF6700")
        self.filelabel.place(relx=0.5, rely=0.6, anchor=N)
        
        self.butone = Button(self.master, text="Menu", command=self.rego)
        self.butone.place(relx=0.5, rely=0.5, anchor=N)
    def rego(self):
        win6 = Toplevel(self.master)
        myWIN = start(win6)
class EasyQ5():
    def __init__(self,master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Question 5 Easy")
        self.master.configure(background="#5130ec")

        self.path = PhotoImage(file = "/Users/jacksonbaker/Desktop/Denmark.gif")
        self.canvas = Canvas(self.master, width = 675, height = 675, bg = "#b50021")
        self.canvas.image = self.path
        self.canvas.pack(expand = YES, fill = "both")
        

        self.canvas.create_image(960, 0, image = self.path, anchor = N)

        self.filelabel = Label(self.master, text = "Question #5, what nation is this?", bg= "#b50021", fg = "#FF6700",font=("Courier", 25))
        self.filelabel.place(relx=0.5, rely=0.6, anchor=N)
        
        self.butone = Button(self.master, text="Sweden", command=self.no)
        self.butone.place(relx=0.33, rely=0.7, anchor=N)

        self.buttwo = Button(self.master, text="Denmark", command=self.Easyend)
        self.buttwo.place(relx=0.66, rely=0.7, anchor=CENTER)

        self.butthree = Button(self.master, text="Norway", command=self.no)
        self.butthree.place(relx=0.33, rely=0.8, anchor=S)

        self.butfour = Button(self.master, text="Finland", command=self.no)
        self.butfour.place(relx=0.66, rely=0.8, anchor=S)
    def Easyend(self):
        win6 = Toplevel(self.master)
        myWIN = Easyending(win6)
    def no(self):
        win219 = Toplevel(self.master)
        myWIN = noeasy(win219)
class EasyQ4():
    def __init__(self,master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Question 4 Weakling")
        self.master.configure(background="#5130ec")

        self.path = PhotoImage(file = "/Users/jacksonbaker/Desktop/Isreal.gif")
        self.canvas = Canvas(self.master, width = 675, height = 675, bg = "#b50021")
        self.canvas.image = self.path
        self.canvas.pack(expand = YES, fill = "both")
        

        self.canvas.create_image(960, 0, image = self.path, anchor = N)

        self.filelabel = Label(self.master, text = "Question #4, what nation is this?", bg= "#b50021", fg = "#FF6700",font=("Courier", 25))
        self.filelabel.place(relx=0.5, rely=0.6, anchor=N)
        
        self.butone = Button(self.master, text="Isreal", command=self.Q5)
        self.butone.place(relx=0.33, rely=0.7, anchor=N)

        self.buttwo = Button(self.master, text="Palestine", command=self.no)
        self.buttwo.place(relx=0.66, rely=0.7, anchor=CENTER)

        self.butthree = Button(self.master, text="Syria", command=self.no)
        self.butthree.place(relx=0.33, rely=0.8, anchor=S)

        self.butfour = Button(self.master, text="Jordan", command=self.no)
        self.butfour.place(relx=0.66, rely=0.8, anchor=S)
    def Q5(self):
        win6 = Toplevel(self.master)
        myWIN = EasyQ5(win6)
    def no(self):
        win219 = Toplevel(self.master)
        myWIN = noeasy(win219)
class EasyQ3():
    def __init__(self,master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Question 3 Easy")
        self.master.configure(background="#5130ec")

        self.path = PhotoImage(file = "/Users/jacksonbaker/Desktop/Nicaragua.gif")
        self.canvas = Canvas(self.master, width = 675, height = 675, bg = "#b50021")
        self.canvas.image = self.path
        self.canvas.pack(expand = YES, fill = "both")
        

        self.canvas.create_image(960, 0, image = self.path, anchor = N)

        self.filelabel = Label(self.master, text = "Question #3, what nation is this?", bg= "#b50021", fg = "#FF6700",font=("Courier", 25))
        self.filelabel.place(relx=0.5, rely=0.6, anchor=N)
        
        self.butone = Button(self.master, text="Nicaragua", command=self.Q4)
        self.butone.place(relx=0.33, rely=0.7, anchor=N)

        self.buttwo = Button(self.master, text="Mexico", command=self.no)
        self.buttwo.place(relx=0.66, rely=0.7, anchor=CENTER)

        self.butthree = Button(self.master, text="Cuba", command=self.no)
        self.butthree.place(relx=0.33, rely=0.8, anchor=S)

        self.butfour = Button(self.master, text="Panama", command=self.no)
        self.butfour.place(relx=0.66, rely=0.8, anchor=S)
    def Q4(self):
        win6 = Toplevel(self.master)
        myWIN = EasyQ4(win6)
    def no(self):
        win219 = Toplevel(self.master)
        myWIN = noeasy(win219)
class EasyQ2():
    def __init__(self,master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Question 2 Easy")
        self.master.configure(background="#5130ec")

        self.path = PhotoImage(file = "/Users/jacksonbaker/Desktop/Peru.gif")
        self.canvas = Canvas(self.master, width = 675, height = 675, bg = "#b50021")
        self.canvas.image = self.path
        self.canvas.pack(expand = YES, fill = "both")
        

        self.canvas.create_image(960, 0, image = self.path, anchor = N)

        self.filelabel = Label(self.master, text = "Question #2, what nation is this?", bg= "#b50021", fg = "#FF6700",font=("Courier", 25))
        self.filelabel.place(relx=0.5, rely=0.6, anchor=N)
        
        self.butone = Button(self.master, text="Nicaragua", command=self.no)
        self.butone.place(relx=0.33, rely=0.7, anchor=N)

        self.buttwo = Button(self.master, text="Argentina", command=self.no)
        self.buttwo.place(relx=0.66, rely=0.7, anchor=CENTER)

        self.butthree = Button(self.master, text="Brazil", command=self.no)
        self.butthree.place(relx=0.33, rely=0.8, anchor=S)

        self.butfour = Button(self.master, text="Peru", command=self.Q3)
        self.butfour.place(relx=0.66, rely=0.8, anchor=S)
    def Q3(self):
        win6 = Toplevel(self.master)
        myWIN = EasyQ3(win6)
    def no(self):
        win219 = Toplevel(self.master)
        myWIN = noeasy(win219)
class noeasy():
    def __init__(self,master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Wrong")
        self.master.configure(background="#b50021")

        self.filelabel = Label(self.master, text = "This was A bit harder, But still no Mercy. Back To the Beggining With You.", bg= "#5130ec", fg = "#FF6700")
        self.filelabel.place(relx=0.5, rely=0.6, anchor=N)
        
        self.butone = Button(self.master, text="Restart", command=self.rego)
        self.butone.place(relx=0.5, rely=0.5, anchor=N)
    def rego(self):
        win300 = Toplevel(self.master)
        myWIN = Easy(win300)
class Easy():
    def __init__(self,master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Question 1 Easy")
        self.master.configure(background="#5130ec")

        self.path = PhotoImage(file = "/Users/jacksonbaker/Desktop/Albania.gif")
        self.canvas = Canvas(self.master, width = 675, height = 675, bg = "#b50021")
        self.canvas.image = self.path
        self.canvas.pack(expand = YES, fill = "both")
        

        self.canvas.create_image(960, 0, image = self.path, anchor = N)

        self.filelabel = Label(self.master, text = "Question #1, what nation is this?", bg= "#b50021", fg = "#FF6700",font=("Courier", 25))
        self.filelabel.place(relx=0.5, rely=0.6, anchor=N)
        
        self.butone = Button(self.master, text="Serbia", command=self.no)
        self.butone.place(relx=0.33, rely=0.7, anchor=N)

        self.buttwo = Button(self.master, text="Albania", command=self.Q2re)
        self.buttwo.place(relx=0.66, rely=0.7, anchor=CENTER)

        self.butthree = Button(self.master, text="Romania", command=self.no)
        self.butthree.place(relx=0.33, rely=0.8, anchor=S)

        self.butfour = Button(self.master, text="Slovenia", command=self.no)
        self.butfour.place(relx=0.66, rely=0.8, anchor=S)
        
    def Q3(self):
        self.master.destroy()
    def Q2re(self):
        win6 = Toplevel(self.master)
        myWIN = EasyQ2(win6)
    def no(self):
        win219 = Toplevel(self.master)
        myWIN = noeasy(win219)
#END OF EASY

#WEAK DIFFICULTY
class Weakending():
    def __init__(self,master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Nice!")
        self.master.configure(background="#5130ec")

        self.filelabel = Label(self.master, text = "Great Job! Now try a harder difficulty", bg= "#5130ec", fg = "#FF6700")
        self.filelabel.place(relx=0.5, rely=0.6, anchor=N)
        
        self.butone = Button(self.master, text="Menu", command=self.rego)
        self.butone.place(relx=0.5, rely=0.5, anchor=N)
    def rego(self):
        win6 = Toplevel(self.master)
        myWIN = start(win6)
class WeakQ5():
    def __init__(self,master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Question 5 Weakling")
        self.master.configure(background="#5130ec")

        self.path = PhotoImage(file = "/Users/jacksonbaker/Desktop/Japan.gif")
        self.canvas = Canvas(self.master, width = 675, height = 675, bg = "#0899e1")
        self.canvas.image = self.path
        self.canvas.pack(expand = YES, fill = "both")
        

        self.canvas.create_image(960, 0, image = self.path, anchor = N)

        self.filelabel = Label(self.master, text = "Question #5, what nation is this?", bg= "#0899e1", fg = "#FF6700",font=("Courier", 25))
        self.filelabel.place(relx=0.5, rely=0.6, anchor=N)
        
        self.butone = Button(self.master, text="Japan", command=self.Weakend)
        self.butone.place(relx=0.33, rely=0.7, anchor=N)

        self.buttwo = Button(self.master, text="Nippon", command=self.no)
        self.buttwo.place(relx=0.66, rely=0.7, anchor=CENTER)

        self.butthree = Button(self.master, text="China", command=self.no)
        self.butthree.place(relx=0.33, rely=0.8, anchor=S)

        self.butfour = Button(self.master, text="Phillipines", command=self.no)
        self.butfour.place(relx=0.66, rely=0.8, anchor=S)
    def Weakend(self):
        win6 = Toplevel(self.master)
        myWIN = Weakending(win6)
    def no(self):
        win219 = Toplevel(self.master)
        myWIN = noweak(win219)
class WeakQ4():
    def __init__(self,master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Question 4 Weakling")
        self.master.configure(background="#5130ec")

        self.path = PhotoImage(file = "/Users/jacksonbaker/Desktop/Uk.gif")
        self.canvas = Canvas(self.master, width = 675, height = 675, bg = "#0899e1")
        self.canvas.image = self.path
        self.canvas.pack(expand = YES, fill = "both")
        

        self.canvas.create_image(960, 0, image = self.path, anchor = N)

        self.filelabel = Label(self.master, text = "Question #4, what nation is this?", bg= "#0899e1", fg = "#FF6700",font=("Courier", 25))
        self.filelabel.place(relx=0.5, rely=0.6, anchor=N)
        
        self.butone = Button(self.master, text="England", command=self.no)
        self.butone.place(relx=0.33, rely=0.7, anchor=N)

        self.buttwo = Button(self.master, text="United Kingdom", command=self.Q5)
        self.buttwo.place(relx=0.66, rely=0.7, anchor=CENTER)

        self.butthree = Button(self.master, text="Malta", command=self.no)
        self.butthree.place(relx=0.33, rely=0.8, anchor=S)

        self.butfour = Button(self.master, text="Great Brittan", command=self.no)
        self.butfour.place(relx=0.66, rely=0.8, anchor=S)
    def Q5(self):
        win6 = Toplevel(self.master)
        myWIN = WeakQ5(win6)
    def no(self):
        win219 = Toplevel(self.master)
        myWIN = noweak(win219)
class WeakQ3():
    def __init__(self,master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Question 3 Weakling")
        self.master.configure(background="#5130ec")

        self.path = PhotoImage(file = "/Users/jacksonbaker/Desktop/Russia.gif")
        self.canvas = Canvas(self.master, width = 675, height = 675, bg = "#0899e1")
        self.canvas.image = self.path
        self.canvas.pack(expand = YES, fill = "both")
        

        self.canvas.create_image(960, 0, image = self.path, anchor = N)

        self.filelabel = Label(self.master, text = "Question #3, what nation is this?", bg= "#0899e1", fg = "#FF6700",font=("Courier", 25))
        self.filelabel.place(relx=0.5, rely=0.6, anchor=N)
        
        self.butone = Button(self.master, text="Albania", command=self.no)
        self.butone.place(relx=0.33, rely=0.7, anchor=N)

        self.buttwo = Button(self.master, text="Crimea", command=self.no)
        self.buttwo.place(relx=0.66, rely=0.7, anchor=CENTER)

        self.butthree = Button(self.master, text="Russia", command=self.Q4)
        self.butthree.place(relx=0.33, rely=0.8, anchor=S)

        self.butfour = Button(self.master, text="Isreal", command=self.no)
        self.butfour.place(relx=0.66, rely=0.8, anchor=S)
    def Q4(self):
        win6 = Toplevel(self.master)
        myWIN = WeakQ4(win6)
    def no(self):
        win219 = Toplevel(self.master)
        myWIN = noweak(win219)
class WeakQ2():
    def __init__(self,master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Question 2 Weakling")
        self.master.configure(background="#5130ec")

        self.path = PhotoImage(file = "/Users/jacksonbaker/Desktop/China.gif")
        self.canvas = Canvas(self.master, width = 675, height = 675, bg = "#0899e1")
        self.canvas.image = self.path
        self.canvas.pack(expand = YES, fill = "both")
        

        self.canvas.create_image(960, 0, image = self.path, anchor = N)

        self.filelabel = Label(self.master, text = "Question #2, what nation is this?", bg= "#0899e1", fg = "#FF6700",font=("Courier", 25))
        self.filelabel.place(relx=0.5, rely=0.6, anchor=N)
        
        self.butone = Button(self.master, text="People's Republic of China", command=self.Q3)
        self.butone.place(relx=0.33, rely=0.7, anchor=N)

        self.buttwo = Button(self.master, text="Canada", command=self.no)
        self.buttwo.place(relx=0.66, rely=0.7, anchor=CENTER)

        self.butthree = Button(self.master, text="Greece", command=self.no)
        self.butthree.place(relx=0.33, rely=0.8, anchor=S)

        self.butfour = Button(self.master, text="The United States", command=self.no)
        self.butfour.place(relx=0.66, rely=0.8, anchor=S)
    def Q3(self):
        win6 = Toplevel(self.master)
        myWIN = WeakQ3(win6)
    def no(self):
        win219 = Toplevel(self.master)
        myWIN = noweak(win219)
class noweak():
    def __init__(self,master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Wrong")
        self.master.configure(background="#5130ec")

        self.filelabel = Label(self.master, text = "How do you even get this wrong? Restart from beggining coward.", bg= "#5130ec", fg = "#FF6700")
        self.filelabel.place(relx=0.5, rely=0.6, anchor=N)
        
        self.butone = Button(self.master, text="Restart", command=self.rego)
        self.butone.place(relx=0.5, rely=0.5, anchor=N)
    def rego(self):
        win300 = Toplevel(self.master)
        myWIN = Weakling(win300)
class Weakling():
    def __init__(self,master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Question 1 Weakling")
        self.master.configure(background="#5130ec")

        self.path = PhotoImage(file = "/Users/jacksonbaker/Desktop/USA.gif")
        self.canvas = Canvas(self.master, width = 675, height = 675, bg = "#0899e1")
        self.canvas.image = self.path
        self.canvas.pack(expand = YES, fill = "both")
        

        self.canvas.create_image(960, 0, image = self.path, anchor = N)

        self.filelabel = Label(self.master, text = "Question #1, what nation is this?", bg= "#0899e1", fg = "#FF6700",font=("Courier", 25))
        self.filelabel.place(relx=0.5, rely=0.6, anchor=N)
        
        self.butone = Button(self.master, text="Russia", command=self.no)
        self.butone.place(relx=0.33, rely=0.7, anchor=N)

        self.buttwo = Button(self.master, text="San Marino", command=self.no)
        self.buttwo.place(relx=0.66, rely=0.7, anchor=CENTER)

        self.butthree = Button(self.master, text="Rome", command=self.no)
        self.butthree.place(relx=0.33, rely=0.8, anchor=S)

        self.butfour = Button(self.master, text="The United States", command=self.Q2re)
        self.butfour.place(relx=0.66, rely=0.8, anchor=S)
        

    def Q2(self):
        self.path = PhotoImage(file = "/Users/jacksonbaker/Desktop/China.gif")
        self.canvas = Canvas(self.master, width = 675, height = 675, bg = "#0899e1")
        self.canvas.image = self.path
        self.canvas.pack(expand = YES, fill = "both")
        

        self.canvas.create_image(960, 0, image = self.path, anchor = N)

        self.filelabel = Label(self.master, text = "Question #2, what nation is this?", bg= "#0899e1", fg = "#FF6700",font=("Courier", 25))
        self.filelabel.place(relx=0.5, rely=0.6, anchor=N)
        
        self.butone = Button(self.master, text="People's Republic of China", command=self.Q3)
        self.butone.place(relx=0.33, rely=0.7, anchor=N)

        self.buttwo = Button(self.master, text="Canada", command=self.no)
        self.buttwo.place(relx=0.66, rely=0.7, anchor=CENTER)

        self.butthree = Button(self.master, text="Greece", command=self.no)
        self.butthree.place(relx=0.33, rely=0.8, anchor=S)

        self.butfour = Button(self.master, text="The United States", command=self.no)
        self.butfour.place(relx=0.66, rely=0.8, anchor=S)
    def Q3(self):
        self.master.destroy()
    def Q2re(self):
        win6 = Toplevel(self.master)
        myWIN = WeakQ2(win6)
    def no(self):
        win219 = Toplevel(self.master)
        myWIN = noweak(win219)
#END OF WEAK



        
        
    
        
        
        
        
class start():
    def __init__(self,master):
        self.master = master
        self.master.geometry("1920x1080")
        self.master.title("Geography Quiz")
        self.master.configure(background="#5130ec")

        self.filelabel = Label(self.master, text = "Geography Quiz", bg= "#5130ec", fg = "#FF6700",font=("Courier", 44))
        self.filelabel.place(relx=0.5, rely=0.3, anchor=N)
        
        self.butthree = Button(self.master, text="Weaking (World Powers)", command=self.weak)
        self.butthree.place(relx=0.5, rely=0.49, anchor=S)
        
        self.butone = Button(self.master, text="Easy (Modern Nations)", command=self.easy)
        self.butone.place(relx=0.5, rely=0.5, anchor=N)

        self.buttwo = Button(self.master, text="Medium (Federal Devisions)", command=self.medium)
        self.buttwo.place(relx=0.498, rely=0.55, anchor=CENTER)

        self.butfour = Button(self.master, text="Hard (Historical Organizations)", command=self.hard)
        self.butfour.place(relx=0.5, rely=0.6, anchor=S)

        self.butfive = Button(self.master, text="Godly (City States and Other Difficult)", command=self.God)
        self.butfive.place(relx=0.5, rely=0.637, anchor=S)

        self.butconstantine = Button(self.master, text="<3", command=self.Constantine)
        self.butconstantine.place(relx=0.5, rely=0.9, anchor=S)

    def easy(self):
        win2 = Toplevel(self.master)
        myWIN = Easy(win2)
    def medium(self):
        win2 = Toplevel(self.master)
        myWIN = Medium(win2)
    def hard(self):
        win2 = Toplevel(self.master)
        myWIN = Hard(win2)
    def weak(self):
        win2 = Toplevel(self.master)
        myWIN = Weakling(win2)
    def God(self):
        win2 = Toplevel(self.master)
        myWIN = Godly(win2)
    def Constantine(self):
        win2 = Toplevel(self.master)
        myWIN = Godly(win2)


def main():
    #to start the code
    win=Tk()
    start5=start(win)       

main()
        
