from tkinter import *
class world():
    def __init__(self,master):
        self.master = master
##        self.master.geometry("1920x1080")
        self.master.title("Greg's Game")
##        self.master.configure(background="#7ab011")
        self.canvas = Canvas(self.master, width=1920, height=1080, bg="#7ab011")
        self.circle=self.canvas.create_oval(0,0,100,100, outline="red", fill="blue")
        self.canvas.grid(row=960, column=540)
        self.canvas.bind_all("w", self.moveup)
        self.canvas.bind_all("a", self.moveleft)
        self.canvas.bind_all("s", self.movedown)
        self.canvas.bind_all("d", self.moveright)

    def moveup(self,arg): 
        for i in range(0, 100, -10): 
            self.canvas.move(self.circle, 0, 3)  
            self.master.update()
            self.master.after(.1)
    def moveleft(self,arg): 
        for i in range(0, 100, -10): 
            self.canvas.move(self.circle, -3, 0)  
            self.master.update()
            self.master.after(.1)
    def movedown(self,arg): 
        for i in range(0, 100, -10): 
            self.canvas.move(self.circle, 0, -3)  
            self.master.update()
            self.master.after(.1) 
    def moveright(self,arg): 
        for i in range(0, 100, -10): 
            self.canvas.move(self.circle, 3, 0)  
            self.master.update()
            self.master.after(.1) 



        
def main():
        win=Tk()
        start1=world(win)
main()
